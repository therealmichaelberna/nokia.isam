.. _linkybook.utils.linux_cliconf:


*********************
nokia.isam.isam
*********************

**Example bare minimum cliconf plugin**


Version added: 0.0.0

.. contents::
   :local:
   :depth: 1


Synopsis
--------
- This is a cliconf plugin that implements the bare minimum necessary for a new device to be supported by the cli_command plugin. Notably this does not do anything for cli_config support.











Status
------


Authors
~~~~~~~

- Ansible Networking Team


.. hint::
    Configuration entries for each entry type have a low to high priority order. For example, a variable that is lower in the list will override a variable that is higher up.
